var i=(o=>(o[o.Close=0]="Close",o[o.High=1]="High",o[o.Medium=2]="Medium",o[o.Low=3]="Low",o[o.Keep=4]="Keep",o))(i||{});export{i as T};
